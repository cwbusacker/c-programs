#ifndef FLYING_OBJECTS_H
#define FLYING_OBJECTS_H

#include "point.h"
#include "velocity.h"

class flyingObjects
{
protected:
   Point location;
   Velocity velocity;
public:
   Point getPoint();
   void setPoint(int x, int y);
   Velocity getVelocity();
   void setVelocity(int dx, int dy);
   bool isAlive();
   void advance(float dx, float dy);
   void kill();
};

#endif