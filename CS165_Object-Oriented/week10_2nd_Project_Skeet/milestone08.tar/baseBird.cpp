#include "baseBird.h"
#include "uiDraw.h"
#include "uiInteract.h"

BaseBird::BaseBird()
{
  location.setX(-200); //these starting points will need to be changed.
  location.setY(random(-200, 200));
  
}

bool BaseBird::hit()
{
   //stub
   return false;
}

void BaseBird::drawGamePoints(int points)
{
   gamePoints += points;
}

void BaseBird::draw()
{
   drawCircle(location, 10);
}