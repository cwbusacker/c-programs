#ifndef STANDARD_BIRD_H
#define STANDARD_BIRD_H
#include "flyingObjects.h"
#include "uiDraw.h"

class StandardBird:public flyingObjects
{
private:
   Point location;
   Velocity velocity;
   int startingy;

public:
   StandardBird();
   void awardPoints();
   void draw();
   void advance();
   int hit();
};
#endif // !STANDARD_BIRD_H
