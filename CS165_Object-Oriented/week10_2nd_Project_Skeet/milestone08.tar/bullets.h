#ifndef BULLETS_H
#define BULLETS_H

#include "flyingObjects.h"



class Bullet: public flyingObjects
{
public:
   Bullet();
   void draw();
   void fire(Point point, float angle);
   void advance();
};

#endif //BULLETS_H