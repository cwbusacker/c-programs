#include "bullets.h"
#include "uiDraw.h"
#include "rifle.h"

Bullet::Bullet()
{
   velocity.setDx(0);
   velocity.setDy(0);
}

void Bullet::draw()
{
   drawDot(location);
}

void Bullet::fire(Point point, float angle)
{
   location = point;
   setVelocity(-10 * cos(angle* 3.1415 / 180), 10 * sin(angle* 3.1415 / 180));
   
   
}
void Bullet::advance()
{
   location.addX(velocity.getDx());
   location.addY(velocity.getDy());
}
