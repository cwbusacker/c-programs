#include "standardBird.h"
StandardBird::StandardBird()
{
   //BaseBird::BaseBird();
   location.setX(-200);
   location.setY(random(-200, 200));
   StandardBird::draw();
   startingy = location.getY();
}
void StandardBird::awardPoints()
{
   //drawGamePoints(1);
}
void StandardBird::draw()
{  
   drawCircle(location, 15);
}
void StandardBird::advance()
{
   velocity.setDx(random(3, 6));
   if (startingy >= 0)
   {
      velocity.setDy(random(-4, 0));
   }
   else if (startingy < 0)
   {
      velocity.setDy(random(0, 4));
   }
   location.addX(velocity.getDx());
   location.addY(velocity.getDy());
   draw();
}
int StandardBird::hit()
{
   //stub
   return 1;
}

