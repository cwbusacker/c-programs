#ifndef BASE_BIRD_H
#define BASE_BIRD_H

#include "point.h"
#include "flyingObjects.h"

class BaseBird: public flyingObjects
{
private:
   int gamePoints;
public:
   BaseBird(); //set the starting point
   bool hit();
   void drawGamePoints(int points);
   void draw();
};

#endif //BASE_BIRD_H