#include "flyingObjects.h"


Point flyingObjects::getPoint()
{
   return location;
}
void flyingObjects::setPoint(int x, int y)
{
   location.setX(x);
   location.setY(y);
}

Velocity flyingObjects::getVelocity()
{
   return velocity;
}
void flyingObjects::setVelocity(int dx, int dy)
{
   velocity.setDx(dx);
   velocity.setDy(dy);
}
bool flyingObjects::isAlive()
{
   return true;
}
void flyingObjects::advance(float dx, float dy)
{
   location.addX(dx);
   location.addY(dy);
}
void flyingObjects::kill()
{
   location.setX(0);
   location.setY(0);
}