#ifndef STANDARD_BIRD_H
#define STANDARD_BIRD_H
#include "flyingObjects.h"
#include "baseBird.h"

class StandardBird:public BaseBird
{
public:
   StandardBird();
   void draw();
   void advance();
   int hit();
};
#endif // !STANDARD_BIRD_H
